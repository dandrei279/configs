// Package td is dummy data for gopls completion test.
package td

import (
	"log"
)

// Now with doc!
func Hello() {
	log.Log
}
