void header_method()
{
  unity_method( 1 );
  fake_method();
}

extern void extern_method( Unity * u );
