const test = {
    foo: 'bar'
}

test.
