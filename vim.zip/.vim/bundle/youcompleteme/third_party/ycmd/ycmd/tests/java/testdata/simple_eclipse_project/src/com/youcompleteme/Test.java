package com.youcompleteme;

public class Test {
  public String test;

  public String doUnicødeTes() {
    String whåtawîdgé = "Test";
    return whåtawîdgé ;
  }

  private int DoWhatever() {
    this.doUnicødeTes();
    this.doUnicødeTes( test );

    TéstClass tésting_with_unicøde = new TéstClass();
    return tésting_with_unicøde.a_test;
  }


  public class TéstClass {
    /** Test in the west */
    public String testywesty;
    public int a_test;
    public boolean åtest;
  }
}
