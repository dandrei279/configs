/**
 * \brief This is a function.
 *
 * This function is defined in a system header.
 */
int test();
