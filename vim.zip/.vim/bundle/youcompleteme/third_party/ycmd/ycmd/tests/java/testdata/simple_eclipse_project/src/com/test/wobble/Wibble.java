package com.test.wobble;

public enum Wibble {
  CUTHBERT,
  DIBBLE,
  TRUMP
}
