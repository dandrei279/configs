class SomeClass():
    def SomeMethod(self):
        pass

def some_function(some_param):
    """
    Parameters
    ----------
    some_param : SomeClass
    """
    some_param.sm
