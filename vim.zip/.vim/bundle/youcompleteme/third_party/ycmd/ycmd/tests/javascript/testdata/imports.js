import func from "library";

func();

import * as lib from "library";

lib.func();

import { func1, func2 } from "library";

func1();
func2();
