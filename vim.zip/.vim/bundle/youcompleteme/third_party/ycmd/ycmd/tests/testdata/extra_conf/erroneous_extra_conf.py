raise Exception( 'Exception raised' )
