#include "a.hpp" // ./a.hpp
#include <a.hpp> // system/a.hpp
#include "b.hpp" // quote/b.hpp
#include <b.hpp> // error
#include "c.hpp" // system/c.hpp
#include <c.hpp> // system/c.hpp
#include "OpenGL/gl.h" // Frameworks/OpenGL.framework/Headers/gl.h
#include <OpenGL/gl.h> // Frameworks/OpenGL.framework/Headers/gl.h
// not an #include line

#include "dir with spaces/d.hpp"
#include <system/
#include :"
#include "OpenGL/
#include <OpenGL/
