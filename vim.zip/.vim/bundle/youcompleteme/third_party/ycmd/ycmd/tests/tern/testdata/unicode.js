var x = 't'.cha
var y = '†'.cha
var x = 't'.cha

var øbjecø = {
  /* unicøde comment */ 'ålpha': '∫eta'
};

øbjecø.a

øbjecø.ålpha
