from multifile3 import my_integer, my_function as my_function_alias
