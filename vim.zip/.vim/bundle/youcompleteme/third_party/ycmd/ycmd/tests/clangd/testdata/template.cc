template < typename  T >
void Foo( T& t )
{
  t.do_a_thing();
}
